import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FundmgrmaintComponent } from './fundmgrmaint.component';

describe('FundmgrmaintComponent', () => {
  let component: FundmgrmaintComponent;
  let fixture: ComponentFixture<FundmgrmaintComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [FundmgrmaintComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(FundmgrmaintComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
