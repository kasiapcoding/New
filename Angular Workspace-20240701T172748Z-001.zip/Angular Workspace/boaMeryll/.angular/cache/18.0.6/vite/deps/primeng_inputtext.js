import {
  InputText,
  InputTextModule
} from "./chunk-6LLG56QP.js";
import "./chunk-V3K4RWW6.js";
import "./chunk-33UENKCN.js";
import "./chunk-6KNU2LW5.js";
import "./chunk-T4EO7UJD.js";
export {
  InputText,
  InputTextModule
};
//# sourceMappingURL=primeng_inputtext.js.map
