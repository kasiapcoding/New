import {
  Button,
  ButtonDirective,
  ButtonModule
} from "./chunk-5KS5ES2I.js";
import "./chunk-UCTLZYUH.js";
import "./chunk-56VQ6LQH.js";
import "./chunk-33UENKCN.js";
import "./chunk-6KNU2LW5.js";
import "./chunk-T4EO7UJD.js";
export {
  Button,
  ButtonDirective,
  ButtonModule
};
//# sourceMappingURL=primeng_button.js.map
