import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FundmgrmaintaltComponent } from './fundmgrmaintalt.component';

describe('FundmgrmaintaltComponent', () => {
  let component: FundmgrmaintaltComponent;
  let fixture: ComponentFixture<FundmgrmaintaltComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [FundmgrmaintaltComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(FundmgrmaintaltComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
