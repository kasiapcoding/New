import { Component } from '@angular/core';

@Component({
  selector: 'app-fundmgrmaintalt',
  standalone: true,
  imports: [],
  templateUrl: './fundmgrmaintalt.component.html',
  styleUrl: './fundmgrmaintalt.component.css'
})
export class FundmgrmaintaltComponent {

}
