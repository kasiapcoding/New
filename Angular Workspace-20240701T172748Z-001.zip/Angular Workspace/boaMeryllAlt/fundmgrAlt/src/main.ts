import { bootstrapApplication } from '@angular/platform-browser';
import { appConfig } from './app/app.config';
import { AppComponent } from './app/app.component';
import { provideAnimationsAsync } from '@angular/platform-browser/animations/async';
import { Routes, RouterModule } from '@angular/router';

// Define your routes if needed
const routes: Routes = [];

// Use RouterModule.forRoot() to configure your routes
const routerModule = RouterModule.forRoot(routes);

// Ensure your providers are set up correctly
const providers = [
  provideAnimationsAsync(),
  // Other providers if needed
];

// Bootstrap your application
bootstrapApplication(AppComponent, {
  ...appConfig,
  providers: providers,
  // imports: [routerModule], // Directly pass RouterModule.forRoot(routes)
})
  .catch((err) => console.error(err));
